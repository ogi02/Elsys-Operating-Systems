"reader.c" and "writer.c" are in separate directories, so it is easier to run them in different terminal windows (there are no conflicts with "./a.out").
